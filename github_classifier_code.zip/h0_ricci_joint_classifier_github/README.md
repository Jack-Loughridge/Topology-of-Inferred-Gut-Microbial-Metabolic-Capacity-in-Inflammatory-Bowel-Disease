# Joint H0 Alpha-Pi and Ricci classifier

- `core/`: sparse joint WKPI + faithful Ricci solver.
- `orchestration/`: locked five-task execution, validation, aggregation and stability analysis.

The manuscript run uses repetition 1 only for all five tasks (25 outer folds), while the orchestration CLI supports larger repeated ranges.
